---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: Templo de Nrisimhadeva
  description: ''
  topimage: ''
  img: ''
  descricao: rrrr
  sideimage: /upload/1712163614717.2798.jpg

---

Nrisimhadeva: A encarnação protetora dos devotos

O Templo de Nrisimhadeva, que se localiza na Vila Nrisimha. Representa a forma transcendental de Vishnu, reverenciado como o Senhor que protege Seus devotos de todas as adversidades. Sua imagem, com a cabeça de leão e o corpo humano (Nara: homem + Simha: leão), simboliza a coragem e a força divina necessárias para superar desafios e purificar a mente.
Este templo oferece adorações diárias pela manhã.