---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: Gokula Livraria e Bistrô
  description: Gastronomia saborosa e devocional
  topimage: /upload/1712246664454.802.jpg
  img: ''
  descricao: rrrr
  sideimage: /upload/1712174115355.9292.jpg

---

Gastronomia Saborosa e Consciente

O Bistro de Nova Gokula é um espaço harmonioso situado no mini-shopping em frente ao Templo Principal. 

Cada refeição deve ser uma jornada para a nutrição física e espiritual quando se oferece o alimento ao Supremo.

Além de um espaço gastronômico, o Bistrô é também uma livraria. Local onde a busca pelo conhecimento espiritual é celebrada ao explorar nossas prateleiras repletas de literatura sagrada e obras inspiradoras que iluminarão sua jornada pessoal. 

Leve consigo não apenas uma refeição, mas também uma lição! 

Servimos almoço, lanches, sucos naturais, sorvetes e muito mais ❤

Desfrute de sua refeição em nosso ambiente acolhedor e absorva a energia positiva no coração da comunidade.

Saiba mais: https://www.instagram.com/gokulabistro/