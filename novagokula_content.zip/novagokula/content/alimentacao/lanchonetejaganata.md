---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: Lanchonete Jagannatha
  description: Sabor aos Pés do Templo
  topimage: null
  img: ''
  descricao: rrrr
  sideimage: /upload/1712173121173.5232.jpg

---

Lanchonete Jagannatha: Sabor aos Pés do Templo

Seja você um devoto ou um visitante, cada visita é uma oportunidade de se conectar com a divindade através da culinária devocional e suas preparações únicas inspiradas na tradição Hare Krishna.

A Lanchonete Jagannatha foi projetada como um espaço acolhedor, onde amigos, familiares e membros da comunidade podem se reunir para desfrutar de momentos especiais após suas práticas espirituais no Templo Principal. Nosso ambiente é uma extensão da atmosfera sagrada, proporcionando um local para a comunhão e alegria.

Localização estratégica ao lado do templo principal

Saiba mais: https://www.facebook.com/profile.php?id=100063861511113