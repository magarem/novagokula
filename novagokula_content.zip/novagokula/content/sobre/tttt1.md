---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: testando!!!
  description: ''
  topimage: null
  sideimage: /img/generic.png

---

rrrrrrr