---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
params_data:
  title: Pousada Nova Gokula
  description: ''
  topimage: ''
  sideimage: /upload/1712160902016.8179.jpg

---

- Ladeada por rio de águas cristalinas, muito verde e jardins;
- Ambiente confortável e acolhedor;
- Cozinha à disposição dos hóspedes;
- Possui Wi-Fi;
- Ventilador;
- Estacionamento;
- Roupa de cama e banho inclusas;
- 3 Suites com capacidade para até 12 pessoas;
- Localizado a 350m da área social da fazenda;
- Preços especiais para grupos e longas estadias.
- Não inclui café da manhã.