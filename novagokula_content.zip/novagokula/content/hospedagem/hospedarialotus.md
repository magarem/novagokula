---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
params_data:
  title: Hospedaria Lótus
  description: ''
  topimage: ''
  sideimage: /upload/1712159580194.7031.jpg

---

- Hospedagem simples em estilo ashram (pousada de peregrinos);
- Possui Wi-Fi;
- Ventilador;
- Estacionamento;
- Roupa de cama e banho inclusas;
- 6 suites exclusivas com capacidade para até 21 pessoas;
(todas as suítes com 1 cama de casal e 1 de solteiro);
- Localizado a 65m da área social da fazenda;
- Preços especiais para grupos e longas estadias;
- Não inclui café da manhã.