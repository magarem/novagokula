---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
params_data:
  title: Casa dos Gurus
  description: ''
  topimage: ''
  sideimage: /upload/1712159833359.8896.jpg

---

- Hospedagem de padrão superior;
- Casa ampla com salão panorâmico;
- Belo jardim e bosque com acesso exclusivo ao rio;
- Ideal para quem deseja conforto e privacidade;
- Tela contra insetos nas portas e janelas;
- Ideal para grupos em retiros de imersão;
- Salão para yoga e workshops;
- Possui Wi-Fi;
- Ar condicionado;
- Estacionamento;
- Roupa de cama e banho inclusas;
- 3 Suites com capacidade para até 12 pessoas;
- Localizado a 300m da área social da fazenda;
- Não inclui café da manhã.