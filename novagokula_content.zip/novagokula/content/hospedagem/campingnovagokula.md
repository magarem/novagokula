---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: string
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
  sideimage:
    label: Imagem lateral
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
params_data:
  title: Camping Nova Gokula
  description: ''
  topimage: ''
  sideimage: /upload/1712160985275.1392.jpg

---

- Área gramada medindo 200 m2 ao lado do rio;
- Dispõe de banheiros masculino e feminino, sem banho quente;
- Acesso de carro ao local;
- Belo jardim e bosque com acesso ao rio;
- Ideal para grupos de jovens;
- Roupa de cama e banho inclusas;
- Localizado a 350m da área social da fazenda;
- Não dispõe de barracas da camping;
- Não inclui café da manhã.