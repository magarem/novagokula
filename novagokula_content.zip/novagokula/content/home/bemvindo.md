---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  video:
    label: Vídeo
    type: string
  buttonsaibamaislink:
    label: Link
    type: string
params_data:
  title: Bem vindo
  video: https://www.youtube.com/embed/Ir6E7wEcJfE
  buttonsaibamaislink: /masterpage/content:sobre:about.md

---

Bem vindo!  
Localizada aos pés da Serra da Mantiqueira, em Pindamonhangaba, a Fazenda Nova Gokula cultiva, há 45 anos, valores de vida simples e uma cultura espiritual baseada nos antigos ensinamentos dos Vedas. Iniciada em 1978, a maior comunidade Hare Krishna da América Latina pertence à Sociedade Internacional para a Consciência de Krishna (ISKCON), conhecida como a maior escola de filosofia védica criada no ocidente. Foi fundada em 1966, em Nova Iorque  por Swami Prabhupada, que trouxe esta ciência conhecida antes apenas por yogis e santos do oriente.