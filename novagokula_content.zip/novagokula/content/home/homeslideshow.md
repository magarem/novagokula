---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  limitNumber:
    label: Limite
    type: string
  time:
    label: Tempo
    type: string
  height:
    label: Tamanho do quadro
    type: string
  images:
    label: Imagens
    type: textarea
params_data:
  title: slideshow22
  limitNumber: '1011'
  time: '2000'
  height: 710
  images: |-
    /upload/slideshow/slide10.jpg
    /upload/slideshow/slide11.jpg
    /upload/slideshow/slide12.jpg
    /upload/slideshow/slide13.jpg
    /upload/slideshow/slide14.jpg
    /upload/slideshow/slide16.jpg
    /upload/slideshow/slide17.jpg
    /upload/slideshow/slide21.jpg
    /upload/slideshow/slide22.jpg
    /upload/slideshow/slide23.jpg
  sideimage: /upload/1706107380465.4895.jpg

---