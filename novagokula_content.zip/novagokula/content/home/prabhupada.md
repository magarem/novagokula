---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: textarea
  image:
    label: Imagem
    type: text+button
    buttonLink:
      label: selecione
      link: openImageManagerModal
  link:
    label: Link
    type: string
params_data:
  title: Prabhupada
  description: ''
  image: /upload/1707610592335.2834.jpg
  link: /masterpage/content:sobre:prabhupada.md

---

Sua Divina Graça
A. C. Bhaktivedanta Swami
Prabhupada Mestre Fundador da Sociedade Internacional para a conciência de Krsna