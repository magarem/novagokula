---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: textarea
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: Susana Uribarri
  description: >-
    Lugar encantador. Fizemos um retiro de Yoga e mantras. Experiência maravilhosa, pessoas gentis, atenção primorosa. Recomendo o kiosque da Eka, e o restaurante Confraria vegana do Jaya Devi.
  topimage: >-
    https://lh3.googleusercontent.com/a-/ALV-UjUFaj0g7PMSqac5m3rLKwvKRSJKPDcVeAFu2TnXP1G4H52Z=w66-h66-p-rp-mo-ba2-br100
  img: ''
  descricao: rrrr

---