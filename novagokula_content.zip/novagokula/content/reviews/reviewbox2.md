---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: textarea
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: Alex Prosa
  description: >-
    Lugar maravilhoso de contemplação reflexão, bem-estar, paz. Hare krishna,
    Hare Hare. Templos para meditação, trilhas, cachoeira, hospedagem, camping,
    lojinhas de conveniência, lanchonete, espaço para almoço, massagens
    ayurvédica, natureza exuberante, muitos pássaros de todas as espécies,
    cânticos, devoção e, acima de tudo, pessoas especiais que dão todo suporte
    aos visitantes.
  topimage: ''
  img: ''
  descricao: rrrr

---