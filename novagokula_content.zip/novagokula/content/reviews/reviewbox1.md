---
components:
  showContent:
    mode: simple
params_schema:
  title:
    label: Título
    type: string
  description:
    label: Descrição
    type: textarea
  topimage:
    label: Imagem superior
    type: text+button
    buttonLink:
      label: Selecionar
      link: openImageManagerModal
params_data:
  title: Tania santos
  description: >-
    Que lugar maravilhoso! Uma tranquilidade longe do que vivo, fomos de bike,
    pude apreciar Is alimentos vegano, sorvete, coxinha de jaca, pudemos nos
    refrescar nas águas límpidas que dava pra vê o fundo ....e os templos nunca
    había visto un desperto, pessoas das lojinhas bem atenciosas
  topimage: >-
    https://lh3.googleusercontent.com/a-/ALV-UjXDh-03wSS5541vK62G0js5NuZ0Iv_NF6huB-MjhcEgUFcw=w66-h66-p-rp-mo-ba5-br100
  img: ''
  descricao: rrrr

---